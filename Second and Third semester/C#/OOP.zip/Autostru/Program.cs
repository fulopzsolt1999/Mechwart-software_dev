﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autostru
{
    internal class Program
    {
        struct Garazs
        {
           public int nap;
           public string ora;
           public string rendszam;
           public int kod;
           public int km;
           public string irany;
        }
        static void Main(string[] args)
        {
            List<Garazs> adatok = new List<Garazs>();
            // a beolvasást másképp csináljuk, egy ciklussal
            // végigmegyünk a fájl sorain, felbontjuk
            // átadjuk egy struktúra típusú példánynak, azt
            // pedig beletesszük egy struktóra típusú listába

            foreach (string sor in File.ReadAllLines("autok.txt"))
            {
                Garazs x = new Garazs();
                string[] resz = sor.Split(' ');
                x.nap = int.Parse(resz[0]);
                x.ora = resz[1];
                x.rendszam = resz[2];
                x.kod = int.Parse(resz[3]);
                x.km = int.Parse(resz[4]);
                if (resz[5]=="0")
                {
                    x.irany = "ki";
                }
                else
                {
                    x.irany = "be";
                }
                adatok.Add(x);
            }
            int nap = 0;
            string rendszam = "";
            foreach (var i in adatok)
            {
                if (i.irany == "ki")
                {
                    nap = i.nap;
                    rendszam = i.rendszam;
                }
            }

            Console.WriteLine($"{nap}. nap, rendszám: {rendszam}");

            Console.Write("Adj meg egy napot: ");
            int beker = int.Parse(Console.ReadLine());

            foreach (var i in adatok)
            {
                if (beker == i.nap)
                {
                    Console.WriteLine($"{i.ora} {i.rendszam} {i.kod} {i.irany}");
                }
            }




            Console.ReadKey();
        }
    }
}
