﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2
{
    internal class Macska
    {
        // Itt ÖSSZEVONJUK a MEZŐ és a PROPERTY LÉTREHOZÁSÁT
        // a MEZŐ NEM FOG LÁTSZÓDNI!!!!!!!
        // PROP + TAB
        public string Nev { get; private set; }
        public int Kor { get; set; }

        public int Suly { get; set; }

        public bool Oltott { get; private set; }

        public Macska(string nev, int kor, int suly, bool oltott)
        {
            Nev = nev;
            Kor = kor;
            Suly = suly;
            Oltott = oltott;
        }
    }
}
