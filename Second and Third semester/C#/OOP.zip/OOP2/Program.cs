﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Macska x = new Macska("Sanyi",5,12,true);
            Macska x1 = new Macska("Cirmi", 1, 4, true);

            Console.WriteLine($"Az első macska neve: {x.Nev}, kora: {x.Kor}, súlya: {x.Suly}");
            Console.WriteLine($"A második macska neve: {x1.Nev}, kora: {x1.Kor}, súlya: {x1.Suly}");
            //Eltelt egy év
            Console.WriteLine($"Az első macska neve: {x.Nev}, kora: {x.Kor +1 }, súlya: {x.Suly - 2}");
            Console.WriteLine($"A második macska neve: {x1.Nev}, kora: {x1.Kor + 1}, súlya: {x1.Suly + 3}");
            // a nevét NEM tudom módosítani
            //x.Nev = "Béla";
            
            
            
            Console.ReadKey();
        }
    }
}
