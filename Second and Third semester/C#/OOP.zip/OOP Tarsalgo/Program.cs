﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Tarsalgo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // a fájlból beolvasott sorokat az
            // osztályban daraboljuk fel
            // Létrehozunk egy objektumokat tároló listát

            List<Szunet> adatok = new List<Szunet>();

            // a fájlból feltöltjük a listát
            foreach (string i in File.ReadAllLines("ajto.txt"))
            {
                Szunet atmenet = new Szunet(i);

                //Console.WriteLine(atmenet.Irany);
                adatok.Add(atmenet);
            }

            // írjuk ki a 10. ember kódját és irányát
            Console.WriteLine($"A 10. ember kódje: {adatok[9].Kod} és iránya: {adatok[9].Irany}");

            // Írjzk ki minden sor sorszámát,
            // az ember kódját és irányát
            int j = 0;
            foreach (Szunet i in adatok)
            {
                j++;
                Console.WriteLine($"{j}. ember kódja: {i.Kod} ebbe az irányba ment: {i.Irany}");
            }





            Console.ReadKey();


        }
    }
}
