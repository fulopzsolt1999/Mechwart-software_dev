﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Tarsalgo
{
    internal class Szunet
    {
        public int Ora { get; set; }
        public int Perc { get; set; }
        public int Kod { get; set; }
        public string Irany { get; set; }
        //a sor a fájlból egy sort jelent, amit paraméterként
        //kap meg a példányosításnál az osztály a
        //konstruktorban
        public Szunet(string sor)
        {
            string[] resz = sor.Split(' ');
            Ora = int.Parse(resz[0]);
            Perc = int.Parse(resz[1]);
            Kod = int.Parse(resz[2]);
            Irany = resz[3];


        }
    }
}
