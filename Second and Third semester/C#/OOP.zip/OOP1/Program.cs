﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP1
{
    // az osztályokat külön fajlba hozzuk létre
    internal class Program
    {
        static void Main(string[] args)
        {
            // Példányosításnak nevezik azt a folyamatot,
            // amikor létrehozunk egy konkrét elemet
            // az osztályból

            // hozzunk létre egyí példányt a Kutya osztályból
            // PÉLDÁNYOSÍTÁSNÁL a program meghívja a KONSTRUKTORT
            Kutya eb = new Kutya();
            eb.nev3 = "Bodri";
            eb.fajta1 = "Puli";
            eb.kor1 = 3;
            eb.oltott1 = true;
            eb.Marmagassag = 25;
            Console.WriteLine($"Az eb marmagassága: {eb.Marmagassag}");
            // próbáljuk megváltoztatni a marmagasság2 értékét,
            // nem fog menni!

            //eb.Marmagassag2 = 65; EZ NEM MEGY!

            Console.WriteLine(eb.Marmagassag2);

            // Már van KONSTRUKTORUNK,
            // hozzunk létre egy új példányt

            Kutya eb2 = new Kutya("fehér",22);

            Console.WriteLine( eb2.Szin );








            Console.ReadKey();
        }
    }
}
