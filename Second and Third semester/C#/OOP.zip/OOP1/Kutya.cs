﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP1
{
    internal class Kutya
    {
        // hozzunk létre azt osztályban mezőket,
        // amik jellemzik az objektumunkat
        // ezt a mezőt NEM látjuk a Program osztályból, 
        // mert nem írtunk elé láthatósági jellemzőt,
        // ilyenkor PRIVATE lesz a láthatósága,
        // ami azt jelenti, hogy csak az osztályból látjuk
        string nev1;
        // ezt sem látjuk kívülről
        private string nev2;
        // hozzunk létre egy publikus mezőt
        public string nev3;
        public string fajta1;
        public int kor1;
        public bool oltott1;

        // Hozzunk létre tulajdonságokat, mert a mezők
        // alapból privátak és a privát mezők
        // módosítását, olvasását a Propertyken
        // keresztül valósítjuk makd meg
        
        private int marmagassag;
        // Property gyors létrehozása a propfull + 2 TAB
        // a GET paraméter jelenti az olvashatóságot
        // a SET paraméter jelenti az írhatóságot
        public int Marmagassag
        {
            get { return marmagassag; }
            set { marmagassag = value; }
        }

        // Hozzunk létre egy marmagasság2-t,
        // amit NE lehessen írni a főprogramban,
        // állandó, beégetett értéke lesz

        private int marmagassag2 = 35;

        public int Marmagassag2
        {
            get { return marmagassag2 = 35; }
            //set { marmagassag2 = 35 value; }
        }
        // privát mezőknek is lehet értéket adni,
        // ami az első híváskor történik meg,
        // inicializálás a neve és egy
        // KONSTRUKTORON keresztül történik!
        // A KONSTRUKTOR olyan függvény, amelynek
        // a neve megegyezik az OSZTÁLY nevével
        // egy osztályban TÖBB konstruktor is lehet,
        // amelyek a paraméterekben térnek el egymástól

        // most PRIVÁT mezőknek fogunk értéket adni,
        // ehhez létrehozunk egy KONSTRUKTORT

        private string szin;
        private int suly;

        // a konstruktornak mindenképp PUBLIKUSNAK kell lennie
        // Így néz ki:
        public Kutya(string szin, int suly)
        {
            this.szin = szin;
            this.suly = suly;
        }

        public Kutya()
        {
        }
        // a THIS szócska arra utal, hogy az a változó
        // az OSZTÁLY egy MEZŐJE és nem ÁTADOTT PARAMÉTER

        // hozzunk létre egy paraméter nélküli konstruktort

        //Hozzunk létre PROPERTYKET a színhez és a súlyhoz
        // modern módon, legrövidebb írással
        // használjuk a PROPFULL + TAB

        

        public string Szin
        {
            get { return szin; }
           // set { szin = value; }
        }




    }
}
